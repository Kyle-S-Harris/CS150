/****************************************************
* AUTHOR: <your name>
* COURSE: CS 150: C++ Programming 1
* SECTION: <class days + time>
* IC (PROJECT)#: <homework #>
* LAST MODIFIED: <date of last change>
*****************************************************/
/*****************************************************************************
* <TITLE OF PROGRAM>
*****************************************************************************
* PROGRAM DESCRIPTION:
* <1-2 sentences describing overall program>
*****************************************************************************
* ALGORITHM:
* <Pseudocode here>
*****************************************************************************
* ALL IMPORTED LIBRARIES NEEDED AND PURPOSE:
* <ex: chrono used for time operations (C++ 11 and on)>
*****************************************************************************/
#include <cstdlib>
#include <iostream>
using namespace std;
int main(int argc, char *argv[])
{
/***** OUTPUT SECTION *****/
cout<<"       /\\\t        /\\\n"
<<"     /    \\           /    \\\n"
<<"   /        \\       /        \\\n";
system("PAUSE");
return EXIT_SUCCESS;
}
